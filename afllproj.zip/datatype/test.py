from lexer import tokenize_input
from parser import parser

test_code = [
    "x",                  
    "y: double = 3.142",           
    "z = 42",             
    "a: int",       
    "b = int(4.7)",     
    'name: str = "gururaj"',       
    "pi: float = 3.14",      
    "c = str(123)",              
]

def run_tests():
    for code in test_code:
        print("\n" + "="*50)
        print(f"Testing: {code}")
        print("-"*50)
        
        print("\n--- TOKENIZING ---")
        try:
            tokens = tokenize_input(code)
            for tok in tokens:
                print(f"Token(type={tok.type}, value={tok.value})")
        except Exception as e:
            print(f"Tokenizing error: {str(e)}")
            
        print("\n--- PARSING ---")
        try:
            result = parser.parse(code)
            print(f"Result: {result}")
        except Exception as e:
            print(f"Parsing error: {str(e)}")
            
        print("\n")

if __name__ == "__main__":
    run_tests()